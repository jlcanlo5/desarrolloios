import UIKit

let cadenaComillas = "Bienvenido a esta materia de \"Desarrollo en iOS\" 2021"
print(cadenaComillas)

let cadenaSalto = "Bienvenio, \n a iOS "
print(cadenaSalto)

func saluda(jugador nombre:String){
    print(nombre)
}

saluda(jugador:"Messi")

func saluda2(_ nombre:String){
    print(nombre)
}

saluda2("Cristiano Ronaldo")

//Arreglos

var titulosStarWars = [String]()

titulosStarWars.append("A new hope")
print(titulosStarWars)

titulosStarWars.insert("El imperio contraataca", at: 1)
print(titulosStarWars)

titulosStarWars += ["3","4","5"]
print(titulosStarWars)

titulosStarWars.remove(at: 4)
print(titulosStarWars)

struct canciones {
    let titulo: String
    let artista: String
    let duracion: Int
    
    var duracionMinutos: String{
        let minutos = duracion / 60
        let segundos = duracion % 60
        return "\(minutos) minutos, \(segundos) segundos"
    }
}

let cancion = canciones(titulo: "El noa noa", artista: "Juan Gabriel", duracion: 150)

print(cancion)
print(cancion.artista)
print(cancion.duracionMinutos)

let cancion2 = canciones(titulo: "El triste", artista: "José José", duracion: 180)
print(cancion.duracionMinutos)

enum desayuno {
    case huevos
    case chilaquiles
    case quesadillas
    
    func postre(_ decision:Bool) -> String{
        if(decision){
            return "si"
        } else {
            return "no"
        }
    }
}

print(desayuno.huevos)
let eleccion = desayuno.huevos
print(eleccion)

print(eleccion.postre(true))
