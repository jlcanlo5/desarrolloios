import UIKit

//Teoría de objetos en swift
//Lo que es una clase y una herencia

//Variables globales y locales
//Si no se agrega un SCOOPE la variable vivirá en memoria

var variableGlobal:Int = 50

func evaluar(){
    var variableLocal:String
    variableLocal="Esto es un texto de ejemplo"
    print ("Global: \(variableGlobal), Local: \(variableLocal)")
}

evaluar()

class Heroe {
    var nombre:String = ""
    var edad:Int = 0
    var tipo = superPoder()
    
    func saludo() -> String {
        return "Soy un Super Héroe mi nombre es \(nombre)"
    }
    
    func muestraPoder() -> String {
        return "Soy \(nombre) y yo puedo \(tipo.accion)"
    }
}

class superPoder{
    var accion:String = ""
}

var objetoHeroe:Heroe = Heroe()

objetoHeroe.nombre="Thor"

print(objetoHeroe.nombre)

print(objetoHeroe.saludo())

var cadena = objetoHeroe.saludo()
print(cadena)

objetoHeroe.tipo.accion="Volar y atraer rayos"

print(objetoHeroe.muestraPoder())

class Persona {
    var nombre:String=""
    var apellido:String=""
    var curp:String=""
    
    func muestraCurp() -> String {
        return "Curp: \(curp)"
    }
}

var objetoPersona:Persona = Persona()

objetoPersona.nombre="Juan"
objetoPersona.apellido="Pérez León"
objetoPersona.curp="RORO901212T5R"

print(objetoPersona.muestraCurp())

class Empleado:Persona {
    var numeroEmpleado:Int
    var puesto:String
    
    init(numeroEmpleado:Int, puesto:String){
        self.numeroEmpleado=numeroEmpleado
        self.puesto=puesto
    }
    
    func datosEmpleado() -> String {
        var datos:String
        datos="Número de empleado: " + String(numeroEmpleado) + "\n"
        datos += "Puesto: " + puesto + "\n"
        datos += "Nombre completo: " + nombre + " " + apellido + "\n"
        datos += "CURP: " + curp
        return datos
    }
}

var objetoEmpleado:Empleado = Empleado(numeroEmpleado:8572, puesto:"Director General")

objetoEmpleado.nombre="Hugo"
objetoEmpleado.apellido="López Muerte"
objetoEmpleado.curp="BARA8112135T5"

print(objetoEmpleado.datosEmpleado())

//Guard es como un if falso, solo entra cuando la condición es falsa

let esMujer:Bool = false
func revisaGenero(){
    guard esMujer else {
        print("Género: Hombre")
        return
    }
}
revisaGenero()
